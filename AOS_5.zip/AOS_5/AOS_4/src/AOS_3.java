/**
 * @author Group 4
 */

import java.util.Random;
import java.awt.Dimension;
import daj.*;
import java.io.*;
import java.util.*;


class AOS_3 extends daj.Application {
    public static final Dimension SIZE =
            new Dimension (450, 450);
    public static int nrOfProgs = 5;
    /**
     * Nodes are created
     * progs provide the process ID
     */
    public daj.Node[] nodes;
    public AProg[] progs;
    /**
     * Request Array for each process
     */
    public static int RN1[];
    public static int RN2[];
    public static int RN3[];
    public static int RN4[];
    public static int RN5[];
    /**
     * LN is used by Token
     */
    public static int LN[];
    /**
     * Constructor
     */

    public AOS_3 () {
        super ("Suzuki Kasami broadcast algorithm", SIZE.width,
                SIZE.height);
        /**
         * Creating the nodes
         * Definition of the requested arrays for each process
         */
        nodes = new daj.Node[nrOfProgs];
        progs = new AProg[nrOfProgs];
        RN1= new int[5];
        RN2= new int[5];
        RN3= new int[5];
        RN4= new int[5];
        RN5= new int[5];
        LN= new int[5];
    } // MainApp

    /**
     * Overriding the main function
     */
    @Override
    public void resetStatistics() {

    }

    public void construct() {
        int i,j;
        Random rand = new Random();
        /**
         * Creating the node in the GUI
         */
        for (i=0; i<nrOfProgs; i++) {
            nodes[i] = node(progs[i]=new AProg(i, (i+1),
                            i==(nrOfProgs-1)),
                    String.valueOf(i), 160*(i%2)+80,
                    160*(i/2)+80);

        }
        /**
         * Linking all the nodes
         */
        for (i=0; i<nrOfProgs; i++) {
            for (j=0; j<nrOfProgs; j++) {
                link(nodes[i], nodes[j]);
            }
        }
    } // construct

    public String getText () {
        return "Suzuki Kasami send token";
    } // getText

    public static void main (String[] args) {
        new AOS_3().run ();
    } // main
}



class AProg extends daj.Program {
    /**
     * @param curDir defines the current node
     *               containing the token in sequence
     */
    private int progID, curDir;
    private boolean haveToken, sentRequest;
    private InChannelSet msgIn;
    private OutChannelSet msgOut;
    private FIFO map;
    private Random rand;


    // Constructor
    public AProg (int progID, int curDir,
                  boolean startWithToken) {
        this.progID = progID;
        if (haveToken = startWithToken) {
            this.curDir = progID;
        }
        else {
            this.curDir = curDir;
        }
        msgIn = new InChannelSet();
        msgOut = new OutChannelSet();
        rand = new Random();
        map = new FIFO();
        sentRequest = false;
    }


    public String getText() {
        return "curDir : " + curDir + " have token : " +
                haveToken + " sent request : " + sentRequest ;
    } // getText

    // Main loop of the Node
    public void main() {
        int fromChannel, outChannels, inChannels, i;
        Msg msg;
        FIFO tokenMap;
        /**
         * Adding the Reply and Request Channels in GUI
         */
        inChannels = in().getSize();
        for (i=0; i<inChannels; i++) {
            msgIn.addChannel(in(i));
        }
        outChannels = out().getSize();
        for (i=0; i<outChannels; i++) {
            msgOut.addChannel(out(i));
        }


// Program main loop
        while(true) {
            if (haveToken) {
/*
Enter critical section ...
*/
                //Changes to LN array
                System.out.println("Current process entering CS "+ progID );
                //System.out.println("Prog ID  " + progID);
                int temp;
                temp = AOS_3.RN1[progID];
                AOS_3.LN[progID] = temp;
                System.out.println("##############################\n LN: ");
                for(int k=0;k < 5;k++)
                {
                    System.out.print( AOS_3.LN[k]); //Display LN
                }
                System.out.println("\n##############################");
// give token to the next "requester"
                if ((i = map.getNextReceiver()) >= 0) {
                    haveToken = false;
                    msgOut.getChannel(i).send(new Token(progID, i,
                            map));
                    map = new FIFO();
                    curDir = i;

                }
            }

            /**        if(i == -1)
            {

            }**/
            if (!haveToken && !sentRequest) {
// request Token
                msgOut.getChannel(curDir).send(new
                        Request(progID, curDir));
                curDir = progID;
                sentRequest = true;

                switch(i) {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:     AOS_3.RN1[i]++;
                                AOS_3.RN2[i]++;
                                AOS_3.RN3[i]++;
                                AOS_3.RN4[i]++;
                                AOS_3.RN5[i]++;
                        break;
                }
                System.out.println("********************************");
                System.out.print("RN1 :");
                for(int k = 0; k < 5;k ++)
                {
                    System.out.print(AOS_3.RN1[k] + " ");
                }
                System.out.println();
                System.out.print("RN2 :");
                for(int k=0;k<5;k++)
                {
                    System.out.print(AOS_3.RN2[k] + " ");
                }
                System.out.println();
                System.out.print("RN3  :");
                for(int k=0;k<5;k++)
                {
                    System.out.print( AOS_3.RN3[k] +" ");
                }
                System.out.println();
                System.out.print("RN4 :");
                for(int k=0;k<5;k++)
                {
                    System.out.print(AOS_3.RN4[k]+ " ");
                }
                System.out.println();
                System.out.print("RN5  : ");
                for(int k=0;k<5;k++)
                {
                    System.out.print( AOS_3.RN5[k] +" ");
                }
                System.out.println();
                System.out.println("********************************");

            }
            fromChannel=msgIn.select();
            msg = (Msg)msgIn.getChannel(fromChannel).receive();
            if (msg.getReceiver() == progID) {
                if (msg instanceof Request) {
                    if (curDir == progID) {
// add the request to the local map
                        map.addToFIFO(msg.getSender());
                    }
                    else {
                        msgOut.getChannel(curDir).send(new
// fwd the request
                                Request(i=msg.getSender(), curDir));
                        curDir = i;
                        msg = null;
                    }
                }
                else { // Token
                    haveToken = true;
                    sentRequest = false;
// merge the local and the tokenMap;
                    tokenMap = ((Token)msg).getMap();
                   while ((i=map.getNextReceiver()) >= 0) {
                        tokenMap.addToFIFO(i);
                    }
                    map = tokenMap;
                    tokenMap = null;
                    msg = null;
                }

            }

            else {
// should never be reached
                System.out.println("Error ! Got Msg from : " +
                        msg.getSender() + " wanted receiver : " +
                        msg.getReceiver());
            }

        } // while (true) main loop
    } // main
} // AProg



class Msg extends daj.Message
{
    protected int sender, receiver;

    public Msg (int sender, int receiver) {
        this.sender = sender;
        this.receiver = receiver;
    }

    public String getText () {
        return "Message from : " + sender + " to : " +
                receiver;
    }

    public int getSender() {
        return sender;
    }

    public int getReceiver() {
        return receiver;
    }
} // Msg

class Request extends Msg {

    public Request (int sender, int receiver) {
        super(sender, receiver);
    }

    public String getText () {
        return "Request from : " + sender + " to : " +
                receiver;
    }
} // Request



class Token extends Msg {
    protected FIFO map;

    public Token (int sender, int receiver, FIFO map) {
        super(sender, receiver);
        this.map = map;
    }

    public FIFO getMap() {
        return map;
    }

    public String getText () {
        return "Token from : " + sender + " to : " +
                receiver;
    }
} // Token



class FIFO {
    ListNode first, last;
    private class ListNode {
        int receiver;
        ListNode next;
        ListNode(int receiver) {
            this.receiver = receiver;
            next = null;
        }
    } // ListNode


    public FIFO() {
        first = null;
        last = null;
    }


    public void addToFIFO(int receiver) {
        ListNode newNode = new ListNode(receiver);
        if (first == null) {
            last = newNode;
            first = last;
        }
        else {
            last.next = newNode;
            last = newNode;
        }
    } // addToFIFO


    // returns id of the next receiver or -1 if there is no
    public int getNextReceiver() {
        int result;
        if (first != null) {
            result = first.receiver;
            first = first.next;
        }
        else {
            result = -1;
        }
        return result;
    } // getNextReceiver

} // FIFO


